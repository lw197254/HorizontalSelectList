

#import <UIKit/UIKit.h>

//! Project version number for PersistenceLayer.
FOUNDATION_EXPORT double PersistenceLayerVersionNumber;

//! Project version string for PersistenceLayer.
FOUNDATION_EXPORT const unsigned char PersistenceLayerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PersistenceLayer/PublicHeader.h>

#import <PersistenceLayer/Note.h>
#import <PersistenceLayer/NoteDAO.h>
