

#import <UIKit/UIKit.h>

#import <BusinessLogicLayer/NoteBL.h>
#import <PersistenceLayer/Note.h>

@interface DetailViewController : UIViewController

@property (strong, nonatomic) id detailItem;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;

@end

