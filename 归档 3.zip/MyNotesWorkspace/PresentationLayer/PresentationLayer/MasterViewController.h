
#import <UIKit/UIKit.h>

#import <BusinessLogicLayer/NoteBL.h>
#import <PersistenceLayer/Note.h>

@class DetailViewController;

@interface MasterViewController : UITableViewController

@property (strong, nonatomic) DetailViewController *detailViewController;


@end

