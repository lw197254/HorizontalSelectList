
#import <UIKit/UIKit.h>

#import <BusinessLogicLayer/NoteBL.h>
#import <PersistenceLayer/Note.h>

@interface AddViewController : UIViewController

@end
