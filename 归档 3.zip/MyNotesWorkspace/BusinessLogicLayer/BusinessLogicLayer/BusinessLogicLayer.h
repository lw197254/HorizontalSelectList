
#import <UIKit/UIKit.h>

//! Project version number for BusinessLogicLayer.
FOUNDATION_EXPORT double BusinessLogicLayerVersionNumber;

//! Project version string for BusinessLogicLayer.
FOUNDATION_EXPORT const unsigned char BusinessLogicLayerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BusinessLogicLayer/PublicHeader.h>

#import <BusinessLogicLayer/NoteBL.h>
