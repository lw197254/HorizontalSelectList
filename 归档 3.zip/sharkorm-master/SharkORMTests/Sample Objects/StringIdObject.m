//
//  StringIdObject.m
//  SharkORMFramework
//
//  Copyright (c) 2016 SharkSync. All rights reserved.
//

#import "StringIdObject.h"

@implementation StringIdObject

@dynamic value,related;

@end
