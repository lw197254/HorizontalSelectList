//
//  WidePerson.m
//  SharkORMFramework
//
//  Copyright (c) 2016 SharkSync. All rights reserved.
//

#import "WidePerson.h"

@implementation WidePerson

@dynamic ex1,ex10,ex11,ex12,ex13,ex14,ex15,ex16,ex17,ex18,ex19,ex2,ex20,ex21,ex22,ex23,ex24,ex25,ex26,ex27,ex28,ex29,ex3,ex30,ex31,ex32,ex33,ex34,ex35,ex36,ex37,ex38,ex39,ex4,ex40,ex41,ex42,ex43,ex44,ex45,ex46,ex47,ex48,ex49,ex5,ex50,ex51,ex52,ex53,ex54,ex55,ex56,ex57,ex58,ex59,ex6,ex60,ex61,ex62,ex63,ex64,ex65,ex66,ex67,ex68,ex69,ex7,ex70,ex71,ex72,ex73,ex74,ex75,ex76,ex77,ex78,ex79,ex8,ex80,ex81,ex82,ex83,ex84,ex85,ex86,ex87,ex88,ex89,ex9,ex90,ex91,ex92,ex93,ex94,ex95,ex96,ex97,ex98,ex99,age,seq;

@end
