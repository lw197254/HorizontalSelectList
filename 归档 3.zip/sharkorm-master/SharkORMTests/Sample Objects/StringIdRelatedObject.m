//
//  StringIdRelatedObject.m
//  SharkORMFramework
//
//  Copyright (c) 2016 SharkSync. All rights reserved.
//

#import "StringIdRelatedObject.h"

@implementation StringIdRelatedObject

@dynamic name,Id;

@end
