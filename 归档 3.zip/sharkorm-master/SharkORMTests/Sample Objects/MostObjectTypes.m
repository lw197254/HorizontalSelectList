//
//  MostObjectTypes.m
//  SharkORMFramework
//
//  Copyright (c) 2016 SharkSync. All rights reserved.
//

#import "MostObjectTypes.h"

@implementation MostObjectTypes

@dynamic array,date,doubleValue,floatValue,intvalue,number,string,dictionary;

@end
