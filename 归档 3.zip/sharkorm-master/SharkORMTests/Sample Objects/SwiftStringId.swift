//
//  SwiftStringId.swift
//  SharkORM
//

import Foundation

@objc(StringIdObjectSwift)
class StringIdObjectSwift : SRKObject {
    
    //override dynamic var Id: String!
    dynamic var value: String?
    
}