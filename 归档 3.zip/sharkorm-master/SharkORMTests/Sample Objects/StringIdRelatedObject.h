//
//  StringIdRelatedObject.h
//  SharkORMFramework
//
//  Copyright (c) 2016 SharkSync. All rights reserved.
//

#import "SharkORM.h"

@interface StringIdRelatedObject : SRKObject

@property (strong, nonatomic) NSString* Id;
@property (strong) NSString* name;

@end
