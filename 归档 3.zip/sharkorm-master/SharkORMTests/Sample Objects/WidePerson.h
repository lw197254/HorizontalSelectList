//
//  WidePerson.h
//  SharkORMFramework
//
//  Copyright (c) 2016 SharkSync. All rights reserved.
//

#import "SharkORM.h"

@interface WidePerson : SRKObject

@property (strong) NSString*         name;
@property (strong) NSString*         ex1;
@property (strong) NSString*         ex2;
@property (strong) NSString*         ex3;
@property (strong) NSString*         ex4;
@property (strong) NSString*         ex5;
@property (strong) NSString*         ex6;
@property (strong) NSString*         ex7;
@property (strong) NSString*         ex8;
@property (strong) NSString*         ex9;
@property (strong) NSString*         ex10;
@property (strong) NSString*         ex11;
@property (strong) NSString*         ex12;
@property (strong) NSString*         ex13;
@property (strong) NSString*         ex14;
@property (strong) NSString*         ex15;
@property (strong) NSString*         ex16;
@property (strong) NSString*         ex17;
@property (strong) NSString*         ex18;
@property (strong) NSString*         ex19;
@property (strong) NSString*         ex20;
@property (strong) NSString*         ex21;
@property (strong) NSString*         ex22;
@property (strong) NSString*         ex23;
@property (strong) NSString*         ex24;
@property (strong) NSString*         ex25;
@property (strong) NSString*         ex26;
@property (strong) NSString*         ex27;
@property (strong) NSString*         ex28;
@property (strong) NSString*         ex29;
@property (strong) NSString*         ex30;
@property (strong) NSString*         ex31;
@property (strong) NSString*         ex32;
@property (strong) NSString*         ex33;
@property (strong) NSString*         ex34;
@property (strong) NSString*         ex35;
@property (strong) NSString*         ex36;
@property (strong) NSString*         ex37;
@property (strong) NSString*         ex38;
@property (strong) NSString*         ex39;
@property (strong) NSString*         ex40;
@property (strong) NSString*         ex41;
@property (strong) NSString*         ex42;
@property (strong) NSString*         ex43;
@property (strong) NSString*         ex44;
@property (strong) NSString*         ex45;
@property (strong) NSString*         ex46;
@property (strong) NSString*         ex47;
@property (strong) NSString*         ex48;
@property (strong) NSString*         ex49;
@property (strong) NSString*         ex50;
@property (strong) NSString*         ex51;
@property (strong) NSString*         ex52;
@property (strong) NSString*         ex53;
@property (strong) NSString*         ex54;
@property (strong) NSString*         ex55;
@property (strong) NSString*         ex56;
@property (strong) NSString*         ex57;
@property (strong) NSString*         ex58;
@property (strong) NSString*         ex59;
@property (strong) NSString*         ex60;
@property (strong) NSString*         ex61;
@property (strong) NSString*         ex62;
@property (strong) NSString*         ex63;
@property (strong) NSString*         ex64;
@property (strong) NSString*         ex65;
@property (strong) NSString*         ex66;
@property (strong) NSString*         ex67;
@property (strong) NSString*         ex68;
@property (strong) NSString*         ex69;
@property (strong) NSString*         ex70;
@property (strong) NSString*         ex71;
@property (strong) NSString*         ex72;
@property (strong) NSString*         ex73;
@property (strong) NSString*         ex74;
@property (strong) NSString*         ex75;
@property (strong) NSString*         ex76;
@property (strong) NSString*         ex77;
@property (strong) NSString*         ex78;
@property (strong) NSString*         ex79;
@property (strong) NSString*         ex80;
@property (strong) NSString*         ex81;
@property (strong) NSString*         ex82;
@property (strong) NSString*         ex83;
@property (strong) NSString*         ex84;
@property (strong) NSString*         ex85;
@property (strong) NSString*         ex86;
@property (strong) NSString*         ex87;
@property (strong) NSString*         ex88;
@property (strong) NSString*         ex89;
@property (strong) NSString*         ex90;
@property (strong) NSString*         ex91;
@property (strong) NSString*         ex92;
@property (strong) NSString*         ex93;
@property (strong) NSString*         ex94;
@property (strong) NSString*         ex95;
@property (strong) NSString*         ex96;
@property (strong) NSString*         ex97;
@property (strong) NSString*         ex98;
@property (strong) NSString*         ex99;
@property  int               age;
@property  int               seq;

@end
