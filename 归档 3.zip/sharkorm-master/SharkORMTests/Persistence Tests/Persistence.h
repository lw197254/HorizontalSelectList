//
//  Persistence.h
//  SharkORM
//
//  Copyright © 2016 SharkSync. All rights reserved.
//

#import "BaseTestCase.h"

@interface Persistence : NSObject<SRKDelegate>

@end
