//
//  Persistence.h
//  SharkORM
//
//  Copyright © 2016 SharkSync. All rights reserved.
//

#import "BaseTestCase.h"

@interface Transactions : BaseTestCase

@end
