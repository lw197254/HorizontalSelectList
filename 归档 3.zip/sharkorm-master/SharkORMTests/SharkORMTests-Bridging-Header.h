//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#include "SharkORM.h"
#import "Location.h"
#import "Department.h"
#import "MostObjectTypes.h"
#import "Person.h"
#import "StringIdObject.h"
#import "StringIdRelatedObject.h"
#import "WidePerson.h"
