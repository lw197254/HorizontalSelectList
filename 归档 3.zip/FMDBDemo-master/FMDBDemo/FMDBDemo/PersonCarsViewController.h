//
//  PersonCarsViewController.h
//  FMDBDemo
//
//  Created by Zeno on 16/5/18.
//  Copyright © 2016年 zenoV. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Person;

@interface PersonCarsViewController : UITableViewController

@property(nonatomic,strong) Person *person;


@end
